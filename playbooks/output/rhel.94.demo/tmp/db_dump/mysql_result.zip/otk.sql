-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: otk_db
-- ------------------------------------------------------
-- Server version	5.7.23-enterprise-commercial-advanced-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oauth_client`
--

DROP TABLE IF EXISTS `oauth_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_client` (
  `client_ident` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'The associated name of the application using this client_id',
  `type` varchar(128) NOT NULL DEFAULT 'oob' COMMENT 'used with oauth 2.0',
  `description` varchar(256) DEFAULT NULL,
  `organization` varchar(128) NOT NULL,
  `registered_by` varchar(128) NOT NULL,
  `created` bigint(20) NOT NULL DEFAULT '0',
  `custom` longtext COMMENT 'longtext object containing custom fields',
  PRIMARY KEY (`client_ident`),
  UNIQUE KEY `uk_oc_name_org` (`name`,`organization`),
  KEY `oc_idx_clientname` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_client`
--

LOCK TABLES `oauth_client` WRITE;
/*!40000 ALTER TABLE `oauth_client` DISABLE KEYS */;
INSERT INTO `oauth_client` VALUES ('123456800-otk','OpenID Connect Basic Client Profile','confidential','Test for OpenID Connect BCP','CA Technologies Inc.','admin',0,'{}'),('530f1602-ddee-41cc-9f14-1975eaa921c5','Daily Silver Application-Daily Partner - Silver','public','Created by CA API Portal','Daily Partner - Silver','admin',1583759400,'{\"apiKey\":\"l75bff5ac779dc40fe9b5c467b67228aba\"}'),('bcdcdb68-662a-480e-884c-e30aa8586e50','Limited Test App-Limited Partner','public','Created by CA API Portal','Limited Partner','admin',1583759400,'{\"apiKey\":\"l73fc6d8debb6d4e4d8c5f61d1945b7b5b\"}'),('TestClient2.0','OAuth2Client','confidential','OAuth 2.0 test client hosted on the ssg','CA Technologies Inc.','admin',0,'{}');
/*!40000 ALTER TABLE `oauth_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_client_key`
--

DROP TABLE IF EXISTS `oauth_client_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_client_key` (
  `client_key` varchar(255) NOT NULL COMMENT 'oauth_consumer_key or client_id',
  `secret` mediumtext NOT NULL COMMENT 'oauth_consumer_key_secret or client_secret or jwks or jwks_uri',
  `scope` varchar(4000) NOT NULL DEFAULT 'oob' COMMENT 'for oauth2, to be defined by the customer and handled accordingly within the policy',
  `callback` varchar(2048) NOT NULL DEFAULT 'oob' COMMENT 'in oauth2 = redirect_uri, contains one URI',
  `environment` varchar(128) NOT NULL DEFAULT 'ALL' COMMENT 'COULD BE SOMETHING LIKE Test, Prod, Integration',
  `expiration` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Date until this key is valid',
  `status` varchar(128) NOT NULL COMMENT 'for validation purposes, ENABLED or DISABLED',
  `created` bigint(20) NOT NULL DEFAULT '0',
  `created_by` varchar(128) NOT NULL,
  `client_ident` varchar(255) NOT NULL COMMENT 'The client that owns this key',
  `client_name` varchar(255) NOT NULL COMMENT 'The name of the client that owns this key. Not normalized for performance.',
  `custom` longtext COMMENT 'longtext object containing custom fields',
  `serviceIds` varchar(256) DEFAULT NULL COMMENT 'A list of service IDs that the key is authorized for',
  `accountPlanMappingIds` varchar(256) DEFAULT NULL COMMENT 'Account plan associated with the client',
  PRIMARY KEY (`client_key`),
  KEY `ock_idx_clientident` (`client_ident`),
  CONSTRAINT `ock_fk_clientIdent` FOREIGN KEY (`client_ident`) REFERENCES `oauth_client` (`client_ident`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_client_key`
--

LOCK TABLES `oauth_client_key` WRITE;
/*!40000 ALTER TABLE `oauth_client_key` DISABLE KEYS */;
INSERT INTO `oauth_client_key` VALUES ('12d20b41-2a60-41a0-9072-9dab1f0ce123','12d20b41-2a60-41a0-9072-9dab1f0ce123','msso openid','oob','all',0,'ENABLED',1583759400,'admin','bcdcdb68-662a-480e-884c-e30aa8586e50','Limited Test App-Limited Partner','{\"apiKey\":\"l73fc6d8debb6d4e4d8c5f61d1945b7b5b\"}',NULL,NULL),('3f1c32d6-03cf-4b84-876a-f15f6fe20811','3f1c32d6-03cf-4b84-876a-f15f6fe20811','msso openid','oob','all',0,'ENABLED',1583759400,'admin','530f1602-ddee-41cc-9f14-1975eaa921c5','Daily Silver Application-Daily Partner - Silver','{\"apiKey\":\"l75bff5ac779dc40fe9b5c467b67228aba\"}',NULL,NULL),('54f0c455-4d80-421f-82ca-9194df24859d','a0f2742f-31c7-436f-9802-b7015b8fd8e6','oob','YOUR_SSG/oauth/v2/client/authcode,YOUR_SSG/oauth/v2/client/implicit','ALL',0,'ENABLED',0,'admin','TestClient2.0','OAuth2Client','{}',NULL,NULL),('5eed868e-7ad0-4172-88f2-704bcf78b61e','2054e4d7-77f2-46c9-bc4d-11a47255a6ec','openid email profile phone address','YOUR_SSG/oauth/v2/client/bcp?auth=done','ALL',0,'ENABLED',0,'admin','123456800-otk','OpenID Connect Basic Client Profile','{}',NULL,NULL),('l73fc6d8debb6d4e4d8c5f61d1945b7b5b','82e43e11f0354f2db3a1f08ab08abd70','oob','oob','ALL',0,'ENABLED',1583759400,'admin','bcdcdb68-662a-480e-884c-e30aa8586e50','Limited Test App-Limited Partner','{\"apiKey\":\"l73fc6d8debb6d4e4d8c5f61d1945b7b5b\"}',NULL,NULL),('l75bff5ac779dc40fe9b5c467b67228aba','896ee292abe848d3a28c2e2d56779c76','oob','oob','ALL',0,'ENABLED',1583759400,'admin','530f1602-ddee-41cc-9f14-1975eaa921c5','Daily Silver Application-Daily Partner - Silver','{\"apiKey\":\"l75bff5ac779dc40fe9b5c467b67228aba\"}',NULL,NULL);
/*!40000 ALTER TABLE `oauth_client_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_id_token`
--

DROP TABLE IF EXISTS `oauth_id_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_id_token` (
  `resource_owner` varchar(128) NOT NULL,
  `azp` varchar(255) NOT NULL,
  `sub` varchar(255) DEFAULT NULL,
  `jwt_id` varchar(512) DEFAULT NULL,
  `jwt` mediumtext NOT NULL,
  `salt` varchar(384) DEFAULT NULL,
  `shared_secret` mediumtext,
  `shared_secret_type` varchar(128) DEFAULT NULL,
  `iss` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL COMMENT 'expiration date in seconds',
  PRIMARY KEY (`resource_owner`,`azp`),
  KEY `oaidt_idx_expiration` (`expiration`),
  KEY `oaidt_idx_azp` (`azp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_id_token`
--

LOCK TABLES `oauth_id_token` WRITE;
/*!40000 ALTER TABLE `oauth_id_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_id_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_initiate`
--

DROP TABLE IF EXISTS `oauth_initiate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_initiate` (
  `token` varchar(128) NOT NULL COMMENT 'for oauth 2.0',
  `secret` varchar(128) DEFAULT NULL COMMENT 'null for oauth 2.0, it does not provide a secret',
  `expiration` bigint(20) NOT NULL DEFAULT '0' COMMENT 'for oauth 2.0, DEFAULT 0 because otherwise timestamp will be set to now() on an update',
  `scope` varchar(4000) DEFAULT NULL COMMENT 'for oauth 2.0, the scope granted by the resource owner',
  `resource_owner` varchar(128) DEFAULT NULL COMMENT 'the authenticated user that granted the token',
  `created` bigint(20) DEFAULT '0' COMMENT 'the date this token (or these tokens in oauth 2.0) were created',
  `verifier` varchar(128) DEFAULT NULL COMMENT 'code verifier',
  `callback` varchar(256) DEFAULT NULL COMMENT 'for oauth 2.0',
  `client_key` varchar(255) NOT NULL COMMENT 'the client that received this token',
  `client_name` varchar(255) NOT NULL COMMENT 'The name of the client that owns this key. Not normalized for performance.',
  `custom` longtext COMMENT 'longtext object containing custom fields',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_initiate`
--

LOCK TABLES `oauth_initiate` WRITE;
/*!40000 ALTER TABLE `oauth_initiate` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_initiate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_session`
--

DROP TABLE IF EXISTS `oauth_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_session` (
  `session_key` varchar(128) NOT NULL,
  `session_group` varchar(128) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`session_key`,`session_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_session`
--

LOCK TABLES `oauth_session` WRITE;
/*!40000 ALTER TABLE `oauth_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_token`
--

DROP TABLE IF EXISTS `oauth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_token` (
  `otk_token_id` varchar(128) NOT NULL,
  `token` varchar(128) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL COMMENT 'null for oauth 2.0, it does not provide a secret',
  `expiration` bigint(20) NOT NULL,
  `scope` varchar(4000) DEFAULT NULL COMMENT 'for 0auth 2.0, the scope granted by the resource owner',
  `resource_owner` varchar(128) NOT NULL COMMENT 'the authenticated user that granted the token',
  `created` bigint(20) DEFAULT '0' COMMENT 'the date this token (or these tokens in oauth 2.0) were created',
  `rtoken` varchar(128) DEFAULT NULL,
  `rexpiration` bigint(20) DEFAULT '0' COMMENT 'DEFAULT 0 because otherwise timestamp will be set to now() on an update',
  `status` varchar(128) NOT NULL COMMENT 'for validation purposes, ENABLED or DISABLED',
  `client_key` varchar(255) NOT NULL COMMENT 'the client_key this token was issued for',
  `client_name` varchar(255) NOT NULL COMMENT 'The name of the client that owns this key. Not normalized for performance.',
  `client_ident` varchar(255) NOT NULL COMMENT 'Client',
  `custom` longtext COMMENT 'longtext object containing custom fields',
  PRIMARY KEY (`otk_token_id`),
  UNIQUE KEY `token` (`token`),
  UNIQUE KEY `rtoken` (`rtoken`),
  KEY `oat_idx_expiration` (`expiration`),
  KEY `oat_idx_rowner_client` (`resource_owner`,`client_key`),
  KEY `oat_idx_rowner` (`resource_owner`),
  KEY `oat_idx_client` (`client_key`),
  KEY `oat_idx_rowner_client_ident` (`resource_owner`,`client_ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_token`
--

LOCK TABLES `oauth_token` WRITE;
/*!40000 ALTER TABLE `oauth_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otk_version`
--

DROP TABLE IF EXISTS `otk_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otk_version` (
  `current_version` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otk_version`
--

LOCK TABLES `otk_version` WRITE;
/*!40000 ALTER TABLE `otk_version` DISABLE KEYS */;
INSERT INTO `otk_version` VALUES ('otk4.3.1');
/*!40000 ALTER TABLE `otk_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_apikey`
--

DROP TABLE IF EXISTS `portal_apikey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_apikey` (
  `apikey_pk` varchar(255) NOT NULL COMMENT 'id from JSON Sync message',
  `apikey` varchar(255) NOT NULL COMMENT 'key from JSON Sync message',
  `apikey_secret` varchar(255) NOT NULL COMMENT 'secret from JSON Sync message',
  `status` varchar(100) NOT NULL COMMENT 'status from JSON sync message',
  `organization_id` varchar(128) NOT NULL COMMENT 'organizationId from JSON sync message. Previously this was accountPlanMappingId',
  `organization` varchar(255) NOT NULL COMMENT 'organizationName from JSON sync message',
  `label` varchar(255) NOT NULL COMMENT 'label from JSON sync message',
  `created_by` varchar(128) NOT NULL COMMENT 'createdBy from JSON sync message',
  `modified_by` varchar(128) NOT NULL COMMENT 'modifiedBy from JSON sync message',
  `created` bigint(20) NOT NULL DEFAULT '0' COMMENT 'the date this apikey was created, which is now in the case of it being a new one',
  `updated` bigint(20) NOT NULL DEFAULT '0' COMMENT 'the date this apikey was updated, which is now',
  `apis` longtext COMMENT 'apis from JSON sync message',
  `value_xml` longtext NOT NULL COMMENT 'Contains more or less all values again',
  PRIMARY KEY (`apikey_pk`),
  UNIQUE KEY `apikey` (`apikey`),
  KEY `papikey_updated` (`updated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_apikey`
--

LOCK TABLES `portal_apikey` WRITE;
/*!40000 ALTER TABLE `portal_apikey` DISABLE KEYS */;
INSERT INTO `portal_apikey` VALUES ('530f1602-ddee-41cc-9f14-1975eaa921c5','l75bff5ac779dc40fe9b5c467b67228aba','896ee292abe848d3a28c2e2d56779c76','active','03dc2322-0f55-458d-9b13-175275fd9809','Daily Partner - Silver','Daily Silver Application-Daily Partner - Silver','admin','admin',1583759400,1584362309,'a0109d14-c279-496b-b76b-76251b28a2e7','PGw3OkFwaUtleSB4bWxuczpsNz0iaHR0cDovL25zLmw3dGVjaC5jb20vMjAxMi8wNC9hcGktbWFuYWdlbWVudCI+DQogICAgPGw3Okxhc3RVcGRhdGU+PCFbQ0RBVEFbMTU4NDM2MjMwOTY1OF1dPjwvbDc6TGFzdFVwZGF0ZT4NCiAgICA8bDc6S2V5PjwhW0NEQVRBW2w3NWJmZjVhYzc3OWRjNDBmZTliNWM0NjdiNjcyMjhhYmFdXT48L2w3OktleT4NCiAgICA8bDc6U3RhdHVzPjwhW0NEQVRBW2FjdGl2ZV1dPjwvbDc6U3RhdHVzPg0KICAgIDxsNzpBY2NvdW50UGxhbk1hcHBpbmdJZD48IVtDREFUQVswM2RjMjMyMi0wZjU1LTQ1OGQtOWIxMy0xNzUyNzVmZDk4MDldXT48L2w3OkFjY291bnRQbGFuTWFwcGluZ0lkPg0KICAgIDxsNzpBY2NvdW50UGxhbk1hcHBpbmdOYW1lPjwhW0NEQVRBW0RhaWx5IFBhcnRuZXIgLSBTaWx2ZXJdXT48L2w3OkFjY291bnRQbGFuTWFwcGluZ05hbWU+DQogICAgPGw3OkN1c3RvbU1ldGFEYXRhPjwhW0NEQVRBW3t9XV0+PC9sNzpDdXN0b21NZXRhRGF0YT4NCiAgICA8bDc6QXBpcz4NCiAgICAgICAgDQo8bDc6QXBpIGFwaUlkPSJhMDEwOWQxNC1jMjc5LTQ5NmItYjc2Yi03NjI1MWIyOGEyZTciIHBsYW5JZD0ibm8tYXBpLXBsYW4iLz4NCiAgICA8L2w3OkFwaXM+DQogICAgPGw3OlNlY3JldD48IVtDREFUQVs4OTZlZTI5MmFiZTg0OGQzYTI4YzJlMmQ1Njc3OWM3Nl1dPjwvbDc6U2VjcmV0Pg0KICAgIDxsNzpMYWJlbD48IVtDREFUQVtEYWlseSBTaWx2ZXIgQXBwbGljYXRpb24tRGFpbHkgUGFydG5lciAtIFNpbHZlcl1dPjwvbDc6TGFiZWw+DQogICAgPGw3OlBsYXRmb3JtPjwhW0NEQVRBW0FMTF1dPjwvbDc6UGxhdGZvcm0+DQogICAgPGw3OlNlY3VyaXR5Pg0KICAgICAgICA8bDc6T0F1dGg+DQogICAgICAgICAgICA8bDc6Q2FsbGJhY2tVcmw+PCFbQ0RBVEFbb29iXV0+PC9sNzpDYWxsYmFja1VybD4NCiAgICAgICAgICAgIDxsNzpTY29wZT48IVtDREFUQVtvb2JdXT48L2w3OlNjb3BlPg0KICAgICAgICAgICAgPGw3OlR5cGU+PCFbQ0RBVEFbcHVibGljXV0+PC9sNzpUeXBlPg0KICAgICAgICA8L2w3Ok9BdXRoPg0KICAgIDwvbDc6U2VjdXJpdHk+DQo8L2w3OkFwaUtleT4='),('bcdcdb68-662a-480e-884c-e30aa8586e50','l73fc6d8debb6d4e4d8c5f61d1945b7b5b','82e43e11f0354f2db3a1f08ab08abd70','active','b38708f3-bac0-4f05-827e-b0180a3646d7','Limited Partner','Limited Test App-Limited Partner','admin','admin',1583759400,1584362309,'a0109d14-c279-496b-b76b-76251b28a2e7','PGw3OkFwaUtleSB4bWxuczpsNz0iaHR0cDovL25zLmw3dGVjaC5jb20vMjAxMi8wNC9hcGktbWFuYWdlbWVudCI+DQogICAgPGw3Okxhc3RVcGRhdGU+PCFbQ0RBVEFbMTU4NDM2MjMwOTY1OF1dPjwvbDc6TGFzdFVwZGF0ZT4NCiAgICA8bDc6S2V5PjwhW0NEQVRBW2w3M2ZjNmQ4ZGViYjZkNGU0ZDhjNWY2MWQxOTQ1YjdiNWJdXT48L2w3OktleT4NCiAgICA8bDc6U3RhdHVzPjwhW0NEQVRBW2FjdGl2ZV1dPjwvbDc6U3RhdHVzPg0KICAgIDxsNzpBY2NvdW50UGxhbk1hcHBpbmdJZD48IVtDREFUQVtiMzg3MDhmMy1iYWMwLTRmMDUtODI3ZS1iMDE4MGEzNjQ2ZDddXT48L2w3OkFjY291bnRQbGFuTWFwcGluZ0lkPg0KICAgIDxsNzpBY2NvdW50UGxhbk1hcHBpbmdOYW1lPjwhW0NEQVRBW0xpbWl0ZWQgUGFydG5lcl1dPjwvbDc6QWNjb3VudFBsYW5NYXBwaW5nTmFtZT4NCiAgICA8bDc6Q3VzdG9tTWV0YURhdGE+PCFbQ0RBVEFbe31dXT48L2w3OkN1c3RvbU1ldGFEYXRhPg0KICAgIDxsNzpBcGlzPg0KICAgICAgICANCjxsNzpBcGkgYXBpSWQ9ImEwMTA5ZDE0LWMyNzktNDk2Yi1iNzZiLTc2MjUxYjI4YTJlNyIgcGxhbklkPSI4NGVlMjJlYy1lNTkyLTQ3OTYtOWNlOC0xODQ5NWYwN2Q5MjMiLz4NCiAgICA8L2w3OkFwaXM+DQogICAgPGw3OlNlY3JldD48IVtDREFUQVs4MmU0M2UxMWYwMzU0ZjJkYjNhMWYwOGFiMDhhYmQ3MF1dPjwvbDc6U2VjcmV0Pg0KICAgIDxsNzpMYWJlbD48IVtDREFUQVtMaW1pdGVkIFRlc3QgQXBwLUxpbWl0ZWQgUGFydG5lcl1dPjwvbDc6TGFiZWw+DQogICAgPGw3OlBsYXRmb3JtPjwhW0NEQVRBW0FMTF1dPjwvbDc6UGxhdGZvcm0+DQogICAgPGw3OlNlY3VyaXR5Pg0KICAgICAgICA8bDc6T0F1dGg+DQogICAgICAgICAgICA8bDc6Q2FsbGJhY2tVcmw+PCFbQ0RBVEFbb29iXV0+PC9sNzpDYWxsYmFja1VybD4NCiAgICAgICAgICAgIDxsNzpTY29wZT48IVtDREFUQVtvb2JdXT48L2w3OlNjb3BlPg0KICAgICAgICAgICAgPGw3OlR5cGU+PCFbQ0RBVEFbcHVibGljXV0+PC9sNzpUeXBlPg0KICAgICAgICA8L2w3Ok9BdXRoPg0KICAgIDwvbDc6U2VjdXJpdHk+DQo8L2w3OkFwaUtleT4=');
/*!40000 ALTER TABLE `portal_apikey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'otk_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-18 11:35:54
